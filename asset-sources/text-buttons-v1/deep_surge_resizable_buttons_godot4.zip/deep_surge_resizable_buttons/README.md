# 深潮 · 可拉伸长方形按钮 / Godot 4

- 四套无文字透明 PNG：normal/hover/pressed/disabled.png (640 × 104)
- 两端星盘为单独 compass.png，保持尺寸与比例，不被九宫格拉伸
- 额外附 SVG 源文件，方便调整深蓝、象牙白配色
- tarot_button.tscn 是可复用的 **Button** 场景：文字、尺寸、点击信号直接在 Godot 编辑器修改，悬停会切换贴图。

## 使用
直接用 Godot 4 打开 `project.godot`，运行查看不同尺寸示例。
在自己的 Godot 项目中只复制 `addons/deep_surge_resizable_buttons`，将 `tarot_button.tscn` 作为子场景拖入，调整 Control 的宽高（推荐最小 220×70），修改 `text`，连接 `pressed` 信号。

九宫格配置（都在场景的 StyleBoxTexture 中）：
- 左右边距各 **82 px**；上下各 **27 px**。
- 这里不依赖 `Node2D.scale`；直接修改 Control 的 Size / Anchors / Container Size Flags。
- 外框四角保持固定，只有中间填充和边缘被拉伸；所有两端纹样是单独子节点不随按钮宽度被拉扁。
- 鼠标 hover、pressed、disabled 状态都已配好，主题面板中可修改字体、颜色等。

注意：`9-slice` 实现的是 **边角及图案不变形**，不是把整张按钮按比例放大。如果想整体放大（包括线条粗细与图标），应单独把控件放在等比缩放的 UI 容器中。

当前环境未找到 Godot 可执行程序，因此没有实机运行测试。
