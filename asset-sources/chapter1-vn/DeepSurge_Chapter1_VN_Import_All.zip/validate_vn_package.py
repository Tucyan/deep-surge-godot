"""Run: python validate_vn_package.py
Checks immutable source, flow references, and one-time routing coverage.
Requires python-docx only for optional DOCX comparison.
"""
import json,hashlib,re
from pathlib import Path
BASE=Path(__file__).parent
s=json.loads((BASE/'vn_source_blocks.json').read_text(encoding='utf-8'))
f=json.loads((BASE/'vn_scene_flow.json').read_text(encoding='utf-8'))
qa=json.loads((BASE/'QA_TEXT_INTEGRITY.json').read_text(encoding='utf-8'))
blocks=s['blocks']; assert len(blocks)==408
line_data=json.loads((BASE/'vn_display_units.json').read_text(encoding='utf-8'))
for b in blocks:
    assert '\n'.join(x['text'] for x in line_data['units'] if x['block_id']==b['id'])==b['text']
assert [b['id'] for b in blocks]==[f'p{i:04d}' for i in range(408)]
assert all('\n'.join(b['lines'])==b['text'] for b in blocks)
sha=hashlib.sha256(json.dumps([b['text'] for b in blocks],ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
assert sha==s['text_sha256']==qa['original_sha256']
scenes={z['id']:z for z in f['scenes']};assert f['entry_scene'] in scenes
references=[];primary=[]
for z in scenes.values():
 a,b=z['source_range'];assert z['block_ids']==[f'p{i:04d}' for i in range(a,b+1)]
 primary+=z['block_ids']
 if z.get('next'):
  assert z['next'] in scenes or z['next']=='UNWRITTEN_NODE12'
 for opt in z.get('menu') or []:
  assert opt['source_block_id'] in {b['id'] for b in blocks}
  assert opt['target'] in scenes
  references.append(opt['source_block_id'])
assert len(primary)==len(set(primary))
assert set(primary+references)=={b['id'] for b in blocks}
assert len(f['clue_catalog'])==13
try:
 from docx import Document
 d=Document(BASE/'DeepSurge_Chapter1_Formatted.docx')
 assert [p.text for p in d.paragraphs]==[b['text'] for b in blocks]
 print('DOCX exact paragraph text: PASS')
except ImportError:
 print('python-docx not installed: skipped DOCX check')
print('SHA256 / 408 paragraphs / 13 clues / scene graph: PASS')
print('Scenarios:',len(scenes),'Main story text stops at node 11; 12-15 not authored.')
